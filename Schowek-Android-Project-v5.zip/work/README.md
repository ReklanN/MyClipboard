# Schowek

Android app for managing reusable text snippets. App label: Schowek.
Launcher icon: purple clipboard on a dark background.
Preserves applicationId and SharedPreferences keys from earlier My Clipboard builds to support in-place upgrades and retaining local data.

Build: `gradle assembleDebug`
