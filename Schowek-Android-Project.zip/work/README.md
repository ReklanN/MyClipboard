# Schowek Android

V6: responsive UI scaling based on device screen width and height. Padding, control sizes, and text sizes scale proportionally on compact and larger phones. Existing package name, preferences keys and debug signing key are retained for upgrade compatibility.

Includes multiple boards, categories, favorites, copy history, JSON backup/import, custom variables, multi-copy and sorting.
