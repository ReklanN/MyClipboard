# Schowek V10

Polished category add/rename dialog with rounded panel, title, helper text, custom input field and matching action buttons. Category operations are scoped to the active board; renaming/deleting a category affects only snippets belonging to that board. Separate per-board category stores retained.
