# Schowek

Category management: long-press a category chip to rename or delete it. Renaming updates every saved text assigned to that category. Deleting a category keeps its texts and moves them to "Bez kategorii".

Includes previous features and screen insets/responsive sizing. Existing applicationId and local preference keys are retained.
