# Schowek V5

Fix for content drawing underneath Android status bar and navigation bar. Applies system window insets to both main screen and full-screen editor, preserving internal spacing. Responsive sizing from V6 retained. Existing app ID and preference keys retained.

Build with `gradle assembleDebug`.
