package pl.myclipboard.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String PREFS = "my_clipboard_store";
    private static final String KEY_ITEMS = "items";
    private static final String KEY_CATEGORIES = "categories";
    private static final String KEY_BOARDS = "boards", KEY_HISTORY = "history", KEY_VARIABLES = "variables", KEY_SORT = "sort";
    private final LinkedHashSet<String> categoryNames = new LinkedHashSet<>(), boardNames = new LinkedHashSet<>();
    private final Set<String> selectedIds = new HashSet<>();
    private final ArrayList<String> history = new ArrayList<>();
    private final java.util.LinkedHashMap<String,String> customVariables = new java.util.LinkedHashMap<>();
    private String activeBoard = "Główne", sortMode = "Najnowsze";
    private boolean selectionMode = false;
    private static final int REQUEST_EXPORT = 7101, REQUEST_IMPORT = 7102;
    private final ArrayList<Snippet> snippets = new ArrayList<>();
    private LinearLayout list, categoryStrip;
    private EditText search;
    private TextView count;
    private String selectedCategory = "Wszystkie";
    private int bg, surface, textColor, muted, stroke, accent, chipSelected, chipText;

    static class Snippet {
        String id, title, category, body, board; boolean favorite; long created;
        Snippet(String t, String c, String b) { this(UUID.randomUUID().toString(),t,c,b,"Główne",false,System.currentTimeMillis()); }
        Snippet(String id,String t,String c,String b,String board,boolean fav,long created) { this.id=id;title=t;category=c;body=b;this.board=board;favorite=fav;this.created=created; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bg = Color.parseColor(night ? "#101014" : "#F6F5F8");
        surface = Color.parseColor(night ? "#1D1C22" : "#FFFFFF");
        textColor = Color.parseColor(night ? "#F4F0F8" : "#201F25");
        muted = Color.parseColor(night ? "#AAA6B2" : "#706D78");
        stroke = Color.parseColor(night ? "#34323B" : "#E6E2EA");
        accent = Color.parseColor(night ? "#D0BCFF" : "#6750A4");
        chipSelected = Color.parseColor(night ? "#51436D" : "#E9DFF8");
        chipText = Color.parseColor(night ? "#FFFFFF" : "#3D2B5D");
        loadItems();
        buildScreen();
        renderCategories();
        renderList();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(12), dp(18), dp(10));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Clipboard");
        title.setTextColor(textColor);
        title.setTextSize(sp(27));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        count = new TextView(this);
        count.setTextColor(muted);
        count.setTextSize(sp(13));
        header.addView(count);
        TextView boards = new TextView(this); boards.setText("▣"); boards.setTextSize(sp(23)); boards.setTextColor(accent); boards.setPadding(dp(12),0,dp(5),0); header.addView(boards); boards.setOnClickListener(v -> showBoardMenu());
        TextView tools = new TextView(this); tools.setText("⋮"); tools.setTextSize(sp(25)); tools.setTextColor(muted); header.addView(tools); tools.setOnClickListener(v -> showToolsMenu());
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("Schowek: " + activeBoard + " · Twoje zapisane teksty");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(sp(14));
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(2);
        subLp.bottomMargin = dp(14);
        root.addView(subtitle, subLp);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(sp(15));
        search.setTextColor(textColor);
        search.setHintTextColor(muted);
        search.setHint("⌕  Szukaj tekstu...");
        search.setPadding(dp(15), 0, dp(15), 0);
        search.setBackground(roundRect(surface, stroke, 14));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { renderList(); }
            public void afterTextChanged(Editable e) {}
        });

        HorizontalScrollView categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryStrip = new LinearLayout(this);
        categoryStrip.setOrientation(LinearLayout.HORIZONTAL);
        categoryStrip.setGravity(Gravity.CENTER_VERTICAL);
        categoryScroll.addView(categoryStrip);
        LinearLayout.LayoutParams catLp = new LinearLayout.LayoutParams(-1, dp(48));
        catLp.topMargin = dp(8);
        catLp.bottomMargin = dp(4);
        root.addView(categoryScroll, catLp);

        if (selectionMode) {
            TextView multi = new TextView(this); multi.setText("Kopiuj zaznaczone ("+selectedIds.size()+")"); multi.setTextColor(Color.WHITE); multi.setGravity(Gravity.CENTER); multi.setBackground(roundRect(accent,accent,12));
            LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,dp(42)); mlp.bottomMargin=dp(6); root.addView(multi,mlp); multi.setOnClickListener(v -> copySelectedSnippets());
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(5), 0, dp(12));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView add = new TextView(this);
        add.setText("＋   Dodaj nowy tekst");
        add.setTextColor(Color.WHITE);
        add.setTextSize(sp(16));
        add.setGravity(Gravity.CENTER);
        add.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        add.setBackground(roundRect(accent, accent, 14));
        add.setOnClickListener(v -> showEditor(-1));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(-1, dp(54));
        addLp.topMargin = dp(8);
        root.addView(add, addLp);
        setContentView(root);
        applySystemBarInsets(root, dp(18), dp(12), dp(18), dp(10));
    }

    private void renderCategories() {
        if (categoryStrip == null) return;
        categoryStrip.removeAllViews();
        LinkedHashSet<String> cats = new LinkedHashSet<>();
        cats.add("Wszystkie");
        cats.addAll(categoryNames);
        for (Snippet s : snippets) if (s.category != null && !s.category.trim().isEmpty()) cats.add(s.category.trim());
        if (!cats.contains(selectedCategory)) selectedCategory = "Wszystkie";
        for (String cat : cats) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(sp(13));
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(15), 0, dp(15), 0);
            boolean selected = cat.equals(selectedCategory);
            chip.setTextColor(selected ? chipText : muted);
            chip.setTypeface(null, selected ? Typeface.BOLD : Typeface.NORMAL);
            chip.setBackground(roundRect(selected ? chipSelected : surface, selected ? chipSelected : stroke, 30));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.rightMargin = dp(8);
            categoryStrip.addView(chip, lp);
            chip.setOnClickListener(v -> { selectedCategory = cat; renderCategories(); renderList(); });
            if (!"Wszystkie".equals(cat)) {
                chip.setOnLongClickListener(v -> {
                    String[] actions = {"Zmień nazwę", "Usuń kategorię"};
                    new AlertDialog.Builder(this).setTitle(cat).setItems(actions, (dialog, which) -> {
                        if (which == 0) {
                            EditText field = new EditText(this);
                            field.setSingleLine(true);
                            field.setText(cat);
                            field.setSelection(field.getText().length());
                            new AlertDialog.Builder(this).setTitle("Zmień nazwę kategorii")
                                .setView(field).setNegativeButton("Anuluj", null)
                                .setPositiveButton("Zapisz", (d, w) -> {
                                    String renamed = field.getText().toString().trim();
                                    if (renamed.isEmpty() || renamed.equals("Wszystkie")) {
                                        Toast.makeText(this, "Podaj prawidłową nazwę.", Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    if (!renamed.equals(cat) && categoryExists(renamed)) {
                                        Toast.makeText(this, "Taka kategoria już istnieje.", Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    categoryNames.remove(cat);
                                    categoryNames.add(renamed);
                                    for (Snippet item : snippets) if (cat.equals(item.category)) item.category = renamed;
                                    if (cat.equals(selectedCategory)) selectedCategory = renamed;
                                    saveCategories(); saveItems(); renderCategories(); renderList();
                                }).show();
                        } else {
                            new AlertDialog.Builder(this).setTitle("Usunąć kategorię?")
                                .setMessage("Teksty pozostaną w schowku, ale zostaną przeniesione do „Bez kategorii”.")
                                .setNegativeButton("Anuluj", null)
                                .setPositiveButton("Usuń", (d, w) -> {
                                    categoryNames.remove(cat);
                                    for (Snippet item : snippets) if (cat.equals(item.category)) item.category = "";
                                    if (cat.equals(selectedCategory)) selectedCategory = "Wszystkie";
                                    saveCategories(); saveItems(); renderCategories(); renderList();
                                }).show();
                        }
                    }).show();
                    return true;
                });
            }
        }
        TextView addCat = new TextView(this);
        addCat.setText("＋ Kategoria");
        addCat.setTextSize(sp(13));
        addCat.setTextColor(accent);
        addCat.setGravity(Gravity.CENTER);
        addCat.setPadding(dp(14), 0, dp(14), 0);
        addCat.setBackground(roundRect(surface, accent, 28));
        categoryStrip.addView(addCat, new LinearLayout.LayoutParams(-2, dp(34)));
        addCat.setOnClickListener(v -> {
            EditText field = new EditText(this);
            field.setSingleLine(true);
            field.setHint("Nazwa kategorii");
            new AlertDialog.Builder(this).setTitle("Nowa kategoria").setView(field)
                .setNegativeButton("Anuluj", null)
                .setPositiveButton("Dodaj", (d, w) -> {
                    String c = field.getText().toString().trim();
                    if (!c.isEmpty() && !c.equals("Wszystkie")) {
                        categoryNames.add(c); saveCategories(); selectedCategory=c;
                        renderCategories(); renderList();
                    }
                }).show();
        });
    }

    private boolean categoryExists(String name) {
        if (categoryNames.contains(name)) return true;
        for (Snippet item : snippets) if (name.equals(item.category)) return true;
        return false;
    }

    private void renderList() {
        if (list == null) return;
        list.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        ArrayList<Integer> order=new ArrayList<>(); for(int k=0;k<snippets.size();k++) order.add(k);
        if("Alfabetycznie".equals(sortMode)) order.sort((a,b)->snippets.get(a).title.compareToIgnoreCase(snippets.get(b).title));
        else if("Ulubione".equals(sortMode)) order.sort((a,b)->Boolean.compare(snippets.get(b).favorite,snippets.get(a).favorite));
        else order.sort((a,b)->Long.compare(snippets.get(b).created,snippets.get(a).created));
        for (int pos=0;pos<order.size();pos++) {
            int i=order.get(pos); Snippet s=snippets.get(i); if(!activeBoard.equals(s.board)) continue;
            boolean matchesCategory = selectedCategory.equals("Wszystkie") || selectedCategory.equals(s.category);
            boolean matchesQuery = q.isEmpty() || s.title.toLowerCase(Locale.ROOT).contains(q)
                    || s.category.toLowerCase(Locale.ROOT).contains(q) || s.body.toLowerCase(Locale.ROOT).contains(q);
            if (!matchesCategory || !matchesQuery) continue;
            final int index = i;
            shown++;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(3), dp(13), dp(3), dp(13));
            list.addView(row, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            row.addView(content, new LinearLayout.LayoutParams(0, -2, 1));

            TextView name = new TextView(this);
            name.setText((s.favorite ? "★  " : "") + (selectedIds.contains(s.id) ? "☑  " : "") + s.title);
            name.setTextColor(textColor);
            name.setTextSize(sp(16));
            name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            content.addView(name);

            String previewText = resolveDates(s.body).replace('\n', ' ').trim();
            TextView preview = new TextView(this);
            preview.setText(previewText);
            preview.setTextColor(textColor);
            preview.setTextSize(sp(14));
            preview.setMaxLines(2);
            preview.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, -2);
            previewLp.topMargin = dp(5);
            content.addView(preview, previewLp);

            TextView meta = new TextView(this);
            meta.setText((s.category.isEmpty() ? "Bez kategorii" : s.category) + "  ·  Dotknij kopiuj, aby skopiować cały tekst");
            meta.setTextColor(muted);
            meta.setTextSize(sp(11));
            LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(-1, -2);
            metaLp.topMargin = dp(5);
            content.addView(meta, metaLp);

            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.CENTER);
            row.addView(actions, new LinearLayout.LayoutParams(dp(88), -1));

            TextView copy = new TextView(this);
            copy.setText("▢");
            copy.setTextSize(sp(28));
            copy.setTextColor(accent);
            copy.setGravity(Gravity.CENTER);
            actions.addView(copy, new LinearLayout.LayoutParams(dp(42), dp(48)));
            copy.setOnClickListener(v -> copySnippet(index));

            TextView more = new TextView(this);
            more.setText("⋮");
            more.setTextSize(sp(25));
            more.setTextColor(muted);
            more.setGravity(Gravity.CENTER);
            actions.addView(more, new LinearLayout.LayoutParams(dp(34), dp(48)));
            more.setOnClickListener(v -> showActions(index));
            content.setOnLongClickListener(v -> { selectionMode=true; if(selectedIds.contains(s.id))selectedIds.remove(s.id);else selectedIds.add(s.id);restoreMain();return true; });
            content.setOnClickListener(v -> { if(selectionMode){if(selectedIds.contains(s.id))selectedIds.remove(s.id);else selectedIds.add(s.id);if(selectedIds.isEmpty())selectionMode=false;restoreMain();}else showEditor(index); });

            View divider = new View(this);
            divider.setBackgroundColor(stroke);
            LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(-1, dp(1));
            list.addView(divider, divLp);
        }
        count.setText(shown + (shown == 1 ? " tekst" : " tekstów"));
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText(snippets.isEmpty() ? "Nie masz jeszcze zapisanych tekstów.\nDodaj pierwszy szablon przyciskiem poniżej." : "Nie znaleziono tekstów.");
            empty.setTextColor(muted);
            empty.setTextSize(sp(14));
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(40), dp(18), dp(40));
            list.addView(empty);
        }
    }

    private void showActions(int index) {
        Snippet s = snippets.get(index);
        String[] actions = {"Edytuj", s.favorite ? "Usuń z ulubionych" : "Dodaj do ulubionych", "Przenieś do kategorii", "Usuń"};
        new AlertDialog.Builder(this).setItems(actions, (d, which) -> {
            if (which == 0) showEditor(index);
            else if (which == 1) { snippets.get(index).favorite=!snippets.get(index).favorite; saveItems(); renderList(); }
            else if (which == 2) {
                ArrayList<String> choices = new ArrayList<>();
                choices.add("Bez kategorii");
                choices.addAll(categoryNames);
                for (Snippet item : snippets) if (!item.category.isEmpty() && !choices.contains(item.category)) choices.add(item.category);
                new AlertDialog.Builder(this).setTitle("Przenieś do kategorii")
                    .setItems(choices.toArray(new String[0]), (dialog, position) -> {
                        snippets.get(index).category = position == 0 ? "" : choices.get(position);
                        saveItems(); selectedCategory="Wszystkie"; renderCategories(); renderList();
                    }).show();
            }
            else new AlertDialog.Builder(this).setTitle("Usunąć tekst?").setMessage(snippets.get(index).title)
                    .setNegativeButton("Anuluj", null).setPositiveButton("Usuń", (x, w) -> {
                        snippets.remove(index); saveItems(); renderCategories(); renderList();
                    }).show();
        }).show();
    }

    private void showEditor(int index) {
        boolean editing = index >= 0;
        Snippet old = editing ? snippets.get(index) : new Snippet("", "", "");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(12), dp(18), dp(10));

        TextView close = new TextView(this);
        close.setText("⊗");
        close.setTextColor(muted);
        close.setTextSize(sp(29));
        close.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(close, new LinearLayout.LayoutParams(-1, dp(60)));
        close.setOnClickListener(v -> restoreMain());

        EditText title = new EditText(this);
        title.setSingleLine(true);
        title.setText(old.title);
        title.setTextColor(textColor);
        title.setHintTextColor(muted);
        title.setTextSize(sp(23));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setHint("Tytuł (opcjonalnie)");
        title.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, dp(65));
        titleLp.topMargin = dp(14);
        root.addView(title, titleLp);

        View divider = new View(this);
        divider.setBackgroundColor(stroke);
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        EditText body = new EditText(this);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setTextColor(textColor);
        body.setHintTextColor(muted);
        body.setTextSize(sp(17));
        body.setBackgroundColor(Color.TRANSPARENT);
        body.setHint("Treść tekstu...");
        body.setText(old.body);
        body.setPadding(0, dp(22), 0, dp(8));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView chosen = new TextView(this);
        final String[] currentCategory = {old.category};
        chosen.setText("Kategoria: " + (currentCategory[0].isEmpty() ? "Bez kategorii" : currentCategory[0]) + "  ▾");
        chosen.setTextColor(accent);
        chosen.setTextSize(sp(14));
        chosen.setPadding(0, dp(10), 0, dp(10));
        root.addView(chosen);
        chosen.setOnClickListener(v -> {
            ArrayList<String> cats = new ArrayList<>();
            cats.add("Bez kategorii");
            cats.addAll(categoryNames);
            for (Snippet sn : snippets) if (!sn.category.isEmpty() && !cats.contains(sn.category)) cats.add(sn.category);
            cats.add("＋ Nowa kategoria");
            new AlertDialog.Builder(this).setTitle("Wybierz kategorię")
                .setItems(cats.toArray(new String[0]), (dialog, which) -> {
                    if (which == cats.size()-1) {
                        EditText field = new EditText(this);
                        field.setHint("Nazwa kategorii");
                        new AlertDialog.Builder(this).setTitle("Nowa kategoria").setView(field)
                            .setNegativeButton("Anuluj", null)
                            .setPositiveButton("Dodaj", (d, w) -> {
                                String c = field.getText().toString().trim();
                                if (!c.isEmpty()) {
                                    categoryNames.add(c); saveCategories();
                                    currentCategory[0]=c; chosen.setText("Kategoria: "+c+"  ▾");
                                }
                            }).show();
                    } else {
                        currentCategory[0] = which == 0 ? "" : cats.get(which);
                        chosen.setText("Kategoria: " + (currentCategory[0].isEmpty() ? "Bez kategorii" : currentCategory[0]) + "  ▾");
                    }
                }).show();
        });

        TextView hint = new TextView(this);
        hint.setText("Zmienne daty: {{DATA_20}}  ·  {{DATA_09}}");
        hint.setTextColor(muted);
        hint.setTextSize(sp(12));
        root.addView(hint);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams bottomLp = new LinearLayout.LayoutParams(-1, dp(70));
        bottomLp.topMargin = dp(12);
        root.addView(bottom, bottomLp);

        TextView insertToday = editorAction("✦  20:00", muted);
        bottom.addView(insertToday, new LinearLayout.LayoutParams(0, dp(52), 1));
        insertToday.setOnClickListener(v -> body.getText().insert(Math.max(0, body.getSelectionStart()), "{{DATA_20}}"));

        TextView insertTomorrow = editorAction("☷  09:00", muted);
        bottom.addView(insertTomorrow, new LinearLayout.LayoutParams(0, dp(52), 1));
        insertTomorrow.setOnClickListener(v -> body.getText().insert(Math.max(0, body.getSelectionStart()), "{{DATA_09}}"));

        TextView insertVariable = editorAction("＃  Zmienna", muted);
        bottom.addView(insertVariable, new LinearLayout.LayoutParams(0, dp(52), 1));
        insertVariable.setOnClickListener(v -> {
            if (customVariables.isEmpty()) { manageVariables(); return; }
            ArrayList<String> keys = new ArrayList<>(customVariables.keySet());
            new AlertDialog.Builder(this).setTitle("Wstaw zmienną").setItems(keys.toArray(new String[0]), (d, which) ->
                body.getText().insert(Math.max(0, body.getSelectionStart()), "{{VAR:" + keys.get(which) + "}}")
            ).show();
        });

        TextView save = editorAction("Zapisz", accent);
        save.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bottom.addView(save, new LinearLayout.LayoutParams(0, dp(52), 1));
        save.setOnClickListener(v -> {
            String b = body.getText().toString();
            String t = title.getText().toString().trim();
            if (b.trim().isEmpty()) {
                Toast.makeText(this, "Wpisz treść tekstu.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (t.isEmpty()) t = b.trim().split("\\n", 2)[0];
            if (t.length() > 55) t = t.substring(0, 55);
            Snippet item = editing ? snippets.get(index) : new Snippet(t,currentCategory[0],b);
            item.title=t; item.category=currentCategory[0]; item.body=b; item.board=activeBoard;
            if (editing) snippets.set(index,item); else snippets.add(0,item);
            if (!currentCategory[0].isEmpty()) categoryNames.add(currentCategory[0]);
            saveCategories(); saveItems(); selectedCategory="Wszystkie";
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(body.getWindowToken(), 0);
            restoreMain();
        });
        setContentView(root);
        applySystemBarInsets(root, dp(18), dp(12), dp(18), dp(10));
    }

    private void applySystemBarInsets(View root, int left, int top, int right, int bottom) {
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int topInset = 0;
            int bottomInset = 0;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                    android.view.WindowInsets.Type.statusBars() |
                    android.view.WindowInsets.Type.navigationBars()
                );
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(left, top + topInset, right, bottom + bottomInset);
            return insets;
        });
        root.requestApplyInsets();
    }

    private TextView editorAction(String label, int color) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextSize(sp(15));
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private void restoreMain() {
        buildScreen();
        renderCategories();
        renderList();
    }

    private void copySnippet(int index) {
        String finalText = resolveVariables(resolveDates(snippets.get(index).body));
        history.add(0,snippets.get(index).title+" · "+new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new java.util.Date()));
        while(history.size()>50)history.remove(history.size()-1); saveHistory();
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(snippets.get(index).title, finalText));
        Toast.makeText(this, "Skopiowano: " + snippets.get(index).title, Toast.LENGTH_SHORT).show();
    }

    private String resolveDates(String input) {
        SimpleDateFormat fmt = new SimpleDateFormat("dd.MM.yyyy", new Locale("pl", "PL"));
        Calendar today = Calendar.getInstance();
        String todayAt20 = fmt.format(today.getTime()) + " 20:00";
        today.add(Calendar.DAY_OF_YEAR, 1);
        String tomorrowAt09 = fmt.format(today.getTime()) + " 09:00";
        return input.replace("{{DATA_20}}", todayAt20).replace("{{DATA_09}}", tomorrowAt09);
    }
    private String resolveVariables(String input) { String out=input; for(String k:customVariables.keySet())out=out.replace("{{VAR:"+k+"}}",customVariables.get(k)); return out; }

    private void loadItems() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String storedCategories = p.getString(KEY_CATEGORIES, "[]");
        try {
            JSONArray ca = new JSONArray(storedCategories);
            for (int i=0; i<ca.length(); i++) categoryNames.add(ca.optString(i));
        } catch (Exception ignored) {}
        try { JSONArray ba=new JSONArray(p.getString(KEY_BOARDS,"[\"Główne\"]")); for(int i=0;i<ba.length();i++)boardNames.add(ba.optString(i)); } catch(Exception ignored){}
        if(boardNames.isEmpty())boardNames.add("Główne"); activeBoard=p.getString("active_board","Główne"); sortMode=p.getString(KEY_SORT,"Najnowsze");
        try { JSONArray ha=new JSONArray(p.getString(KEY_HISTORY,"[]"));for(int i=0;i<ha.length();i++)history.add(ha.optString(i)); }catch(Exception ignored){}
        try { JSONObject va=new JSONObject(p.getString(KEY_VARIABLES,"{}"));java.util.Iterator<String> it=va.keys();while(it.hasNext()){String k=it.next();customVariables.put(k,va.optString(k));} }catch(Exception ignored){}
        String raw = p.getString(KEY_ITEMS, null);
        if (raw != null) try {
            JSONArray a = new JSONArray(raw);
            for (int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Snippet sn=new Snippet(o.optString("id",UUID.randomUUID().toString()),o.optString("title"),o.optString("category"),o.optString("body"),o.optString("board","Główne"),o.optBoolean("favorite",false),o.optLong("created",System.currentTimeMillis()));snippets.add(sn);boardNames.add(sn.board);}
        } catch (Exception ignored) {}
        for (Snippet item : snippets) if (!item.category.isEmpty()) categoryNames.add(item.category);
        if (snippets.isEmpty() && !p.getBoolean("initialized", false)) {
            snippets.add(new Snippet("🔥 LICYTACJA – BIŻUTERIA 📿", "Biżuteria", "🔥 LICYTACJA – BIŻUTERIA📿\nLicytacja❗️\nStart-40 zł\nPrzebicie: min 5zł\nKoniec licytacji- {{DATA_20}}\nNa sprzedaż nowa biżuteria z próbą 925\n.\nW komplecie łańcuszek 40 cm x 2mm\n.\nWysyłka InPost"));
            saveItems(); p.edit().putBoolean("initialized", true).apply();
        }
    }

    private void saveCategories() {
        JSONArray a = new JSONArray();
        for (String c : categoryNames) a.put(c);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_CATEGORIES, a.toString()).apply();
    }

    private void saveHistory(){JSONArray a=new JSONArray();for(String h:history)a.put(h);getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_HISTORY,a.toString()).apply();}
    private void saveBoards(){JSONArray a=new JSONArray();for(String b:boardNames)a.put(b);getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_BOARDS,a.toString()).putString("active_board",activeBoard).apply();}
    private void saveVariables(){JSONObject o=new JSONObject();try{for(String k:customVariables.keySet())o.put(k,customVariables.get(k));}catch(Exception ignored){}getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_VARIABLES,o.toString()).apply();}
    private void showBoardMenu(){ArrayList<String> c=new ArrayList<>(boardNames);c.add("＋ Dodaj schowek");new AlertDialog.Builder(this).setTitle("Moje schowki").setItems(c.toArray(new String[0]),(d,w)->{if(w==c.size()-1){EditText e=new EditText(this);e.setHint("Nazwa schowka");new AlertDialog.Builder(this).setTitle("Nowy schowek").setView(e).setNegativeButton("Anuluj",null).setPositiveButton("Dodaj",(x,y)->{String n=e.getText().toString().trim();if(!n.isEmpty()){boardNames.add(n);activeBoard=n;saveBoards();restoreMain();}}).show();}else{activeBoard=c.get(w);selectedCategory="Wszystkie";saveBoards();restoreMain();}}).show();}
    private void showToolsMenu(){String[] a={"Ulubione (sortuj na górze)","Historia kopiowania","Sortowanie","Własne zmienne","Eksport kopii zapasowej","Import kopii zapasowej","Zaznacz teksty do łącznego kopiowania"};new AlertDialog.Builder(this).setTitle("Narzędzia").setItems(a,(d,w)->{if(w==0){sortMode="Ulubione";saveSort();restoreMain();}else if(w==1)new AlertDialog.Builder(this).setTitle("Ostatnio kopiowane").setItems(history.toArray(new String[0]),(x,y)->Toast.makeText(this,history.get(y),Toast.LENGTH_SHORT).show()).setPositiveButton("Zamknij",null).show();else if(w==2)new AlertDialog.Builder(this).setTitle("Sortuj teksty").setItems(new String[]{"Najnowsze","Alfabetycznie","Ulubione"},(x,y)->{sortMode=new String[]{"Najnowsze","Alfabetycznie","Ulubione"}[y];saveSort();restoreMain();}).show();else if(w==3)manageVariables();else if(w==4){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"my-clipboard-backup.json");startActivityForResult(i,REQUEST_EXPORT);}else if(w==5){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQUEST_IMPORT);}else{selectionMode=!selectionMode;selectedIds.clear();restoreMain();}}).show();}
    private void saveSort(){getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_SORT,sortMode).apply();}
    private void manageVariables(){EditText k=new EditText(this);k.setHint("Nazwa, np. KLIENT");EditText v=new EditText(this);v.setHint("Wartość, np. Adam");LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(16),0,dp(16),0);box.addView(k);box.addView(v);new AlertDialog.Builder(this).setTitle("Własna zmienna").setMessage("W szablonie wpisz {{VAR:KLIENT}} (nazwa bez spacji)").setView(box).setNegativeButton("Anuluj",null).setPositiveButton("Zapisz",(d,w)->{String key=k.getText().toString().trim().toUpperCase(Locale.ROOT),val=v.getText().toString();if(!key.isEmpty()&&key.matches("[A-Z0-9_]+")){customVariables.put(key,val);saveVariables();Toast.makeText(this,"Zapisano {{VAR:"+key+"}}",Toast.LENGTH_LONG).show();}else Toast.makeText(this,"Użyj liter, cyfr i _",Toast.LENGTH_SHORT).show();}).show();}
    private void copySelectedSnippets(){StringBuilder b=new StringBuilder();for(Snippet sn:snippets)if(selectedIds.contains(sn.id)&&activeBoard.equals(sn.board)){if(b.length()>0)b.append("\n\n");b.append(resolveVariables(resolveDates(sn.body)));}if(b.length()>0){((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("My Clipboard",b.toString()));Toast.makeText(this,"Skopiowano zaznaczone teksty",Toast.LENGTH_SHORT).show();}selectedIds.clear();selectionMode=false;restoreMain();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;try{Uri uri=data.getData();if(requestCode==REQUEST_EXPORT){JSONObject root=new JSONObject();JSONArray items=new JSONArray();for(Snippet sn:snippets){JSONObject o=new JSONObject();o.put("id",sn.id);o.put("title",sn.title);o.put("category",sn.category);o.put("body",sn.body);o.put("board",sn.board);o.put("favorite",sn.favorite);o.put("created",sn.created);items.put(o);}root.put("items",items);JSONArray boards=new JSONArray();for(String b:boardNames)boards.put(b);root.put("boards",boards);root.put("categories",new JSONArray(categoryNames));JSONObject vars=new JSONObject();for(String k:customVariables.keySet())vars.put(k,customVariables.get(k));root.put("variables",vars);try(java.io.OutputStream os=getContentResolver().openOutputStream(uri)){os.write(root.toString(2).getBytes("UTF-8"));}Toast.makeText(this,"Kopia zapasowa zapisana",Toast.LENGTH_SHORT).show();}else if(requestCode==REQUEST_IMPORT){StringBuilder raw=new StringBuilder();try(java.io.InputStream is=getContentResolver().openInputStream(uri)){byte[] buf=new byte[4096];int n;while((n=is.read(buf))>0)raw.append(new String(buf,0,n,"UTF-8"));}JSONObject root=new JSONObject(raw.toString());JSONArray items=root.optJSONArray("items");if(items!=null){snippets.clear();for(int i=0;i<items.length();i++){JSONObject o=items.getJSONObject(i);snippets.add(new Snippet(o.optString("id",UUID.randomUUID().toString()),o.optString("title"),o.optString("category"),o.optString("body"),o.optString("board","Główne"),o.optBoolean("favorite"),o.optLong("created",System.currentTimeMillis())));}}JSONArray boards=root.optJSONArray("boards");if(boards!=null){boardNames.clear();for(int i=0;i<boards.length();i++)boardNames.add(boards.optString(i));}JSONArray cats=root.optJSONArray("categories");if(cats!=null){categoryNames.clear();for(int i=0;i<cats.length();i++)categoryNames.add(cats.optString(i));}JSONObject vars=root.optJSONObject("variables");if(vars!=null){customVariables.clear();java.util.Iterator<String> it=vars.keys();while(it.hasNext()){String k=it.next();customVariables.put(k,vars.optString(k));}}if(boardNames.isEmpty())boardNames.add("Główne");activeBoard=boardNames.iterator().next();saveItems();saveCategories();saveBoards();saveVariables();restoreMain();Toast.makeText(this,"Kopia przywrócona",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"Błąd kopii: "+e.getMessage(),Toast.LENGTH_LONG).show();}}

    private void saveItems() {
        JSONArray a = new JSONArray();
        try { for (Snippet s : snippets) { JSONObject o = new JSONObject(); o.put("id",s.id);o.put("title",s.title);o.put("category",s.category);o.put("body",s.body);o.put("board",s.board);o.put("favorite",s.favorite);o.put("created",s.created);a.put(o); } }
        catch (Exception ignored) {}
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ITEMS, a.toString()).apply();
    }

    private GradientDrawable roundRect(int color, int border, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), border); return d;
    }
    // Responsywne skalowanie względem szerokości i wysokości ekranu.
    // Zachowuje wygląd na typowym telefonie, a na mniejszych ekranach
    // delikatnie zmniejsza odstępy i elementy; na dużych nie rozciąga przesadnie.
    private float uiScale() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float widthDp = dm.widthPixels / dm.density;
        float heightDp = dm.heightPixels / dm.density;
        float widthScale = widthDp / 393f;
        float heightScale = heightDp / 820f;
        return Math.max(0.86f, Math.min(1.16f, Math.min(widthScale, heightScale)));
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density * uiScale() + 0.5f);
    }

    private float sp(float v) {
        return v * uiScale();
    }
}
