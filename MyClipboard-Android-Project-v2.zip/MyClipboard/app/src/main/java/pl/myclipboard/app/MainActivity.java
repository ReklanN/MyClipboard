package pl.myclipboard.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "my_clipboard_store";
    private static final String KEY_ITEMS = "items";
    private static final String KEY_CATEGORIES = "categories";
    private final LinkedHashSet<String> categoryNames = new LinkedHashSet<>();
    private final ArrayList<Snippet> snippets = new ArrayList<>();
    private LinearLayout list, categoryStrip;
    private EditText search;
    private TextView count;
    private String selectedCategory = "Wszystkie";
    private int bg, surface, textColor, muted, stroke, accent, chipSelected, chipText;

    static class Snippet {
        String title, category, body;
        Snippet(String t, String c, String b) { title=t; category=c; body=b; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bg = Color.parseColor(night ? "#101014" : "#F6F5F8");
        surface = Color.parseColor(night ? "#1D1C22" : "#FFFFFF");
        textColor = Color.parseColor(night ? "#F4F0F8" : "#201F25");
        muted = Color.parseColor(night ? "#AAA6B2" : "#706D78");
        stroke = Color.parseColor(night ? "#34323B" : "#E6E2EA");
        accent = Color.parseColor(night ? "#D0BCFF" : "#6750A4");
        chipSelected = Color.parseColor(night ? "#51436D" : "#E9DFF8");
        chipText = Color.parseColor(night ? "#FFFFFF" : "#3D2B5D");
        loadItems();
        buildScreen();
        renderCategories();
        renderList();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(12), dp(18), dp(10));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Clipboard");
        title.setTextColor(textColor);
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        count = new TextView(this);
        count.setTextColor(muted);
        count.setTextSize(13);
        header.addView(count);
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("Twoje zapisane teksty");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(2);
        subLp.bottomMargin = dp(14);
        root.addView(subtitle, subLp);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(textColor);
        search.setHintTextColor(muted);
        search.setHint("⌕  Szukaj tekstu...");
        search.setPadding(dp(15), 0, dp(15), 0);
        search.setBackground(roundRect(surface, stroke, 14));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { renderList(); }
            public void afterTextChanged(Editable e) {}
        });

        HorizontalScrollView categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryStrip = new LinearLayout(this);
        categoryStrip.setOrientation(LinearLayout.HORIZONTAL);
        categoryStrip.setGravity(Gravity.CENTER_VERTICAL);
        categoryScroll.addView(categoryStrip);
        LinearLayout.LayoutParams catLp = new LinearLayout.LayoutParams(-1, dp(48));
        catLp.topMargin = dp(8);
        catLp.bottomMargin = dp(4);
        root.addView(categoryScroll, catLp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(5), 0, dp(12));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView add = new TextView(this);
        add.setText("＋   Dodaj nowy tekst");
        add.setTextColor(Color.WHITE);
        add.setTextSize(16);
        add.setGravity(Gravity.CENTER);
        add.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        add.setBackground(roundRect(accent, accent, 14));
        add.setOnClickListener(v -> showEditor(-1));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(-1, dp(54));
        addLp.topMargin = dp(8);
        root.addView(add, addLp);
        setContentView(root);
    }

    private void renderCategories() {
        if (categoryStrip == null) return;
        categoryStrip.removeAllViews();
        LinkedHashSet<String> cats = new LinkedHashSet<>();
        cats.add("Wszystkie");
        for (Snippet s : snippets) if (s.category != null && !s.category.trim().isEmpty()) cats.add(s.category.trim());
        if (!cats.contains(selectedCategory)) selectedCategory = "Wszystkie";
        for (String cat : cats) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(13);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(15), 0, dp(15), 0);
            boolean selected = cat.equals(selectedCategory);
            chip.setTextColor(selected ? chipText : muted);
            chip.setTypeface(null, selected ? Typeface.BOLD : Typeface.NORMAL);
            chip.setBackground(roundRect(selected ? chipSelected : surface, selected ? chipSelected : stroke, 30));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.rightMargin = dp(8);
            categoryStrip.addView(chip, lp);
            chip.setOnClickListener(v -> { selectedCategory = cat; renderCategories(); renderList(); });
        }
        TextView addCategory = new TextView(this);
        addCategory.setText("＋ Kategoria");
        addCategory.setTextSize(13);
        addCategory.setGravity(Gravity.CENTER);
        addCategory.setPadding(dp(13), 0, dp(13), 0);
        addCategory.setTextColor(accent);
        addCategory.setBackground(roundRect(surface, accent, 30));
        LinearLayout.LayoutParams addCatLp = new LinearLayout.LayoutParams(-2, dp(34));
        addCatLp.rightMargin = dp(8);
        categoryStrip.addView(addCategory, addCatLp);
        addCategory.setOnClickListener(v -> showAddCategoryDialog());
    }

    private void showAddCategoryDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Np. Perfumy, Zegarki, Biżuteria");
        new AlertDialog.Builder(this)
                .setTitle("Nowa kategoria")
                .setMessage("Dodaj kategorię, a potem przypisz do niej teksty.")
                .setView(input)
                .setNegativeButton("Anuluj", null)
                .setPositiveButton("Dodaj", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Wpisz nazwę kategorii.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    categoryNames.add(name);
                    selectedCategory = name;
                    saveCategories();
                    renderCategories();
                    renderList();
                    Toast.makeText(this, "Dodano kategorię: " + name, Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showMoveDialog(int index) {
        ArrayList<String> choices = new ArrayList<>();
        choices.add("Bez kategorii");
        choices.addAll(categoryNames);
        for (Snippet item : snippets) {
            if (item.category != null && !item.category.trim().isEmpty() && !choices.contains(item.category.trim()))
                choices.add(item.category.trim());
        }
        String[] labels = choices.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Przenieś do kategorii")
                .setItems(labels, (dialog, which) -> {
                    snippets.get(index).category = which == 0 ? "" : choices.get(which);
                    if (!snippets.get(index).category.isEmpty()) categoryNames.add(snippets.get(index).category);
                    saveCategories();
                    saveItems();
                    selectedCategory = "Wszystkie";
                    renderCategories();
                    renderList();
                    Toast.makeText(this, "Zmieniono kategorię tekstu.", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void renderList() {
        if (list == null) return;
        list.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        for (int i = 0; i < snippets.size(); i++) {
            Snippet s = snippets.get(i);
            boolean matchesCategory = selectedCategory.equals("Wszystkie") || selectedCategory.equals(s.category);
            boolean matchesQuery = q.isEmpty() || s.title.toLowerCase(Locale.ROOT).contains(q)
                    || s.category.toLowerCase(Locale.ROOT).contains(q) || s.body.toLowerCase(Locale.ROOT).contains(q);
            if (!matchesCategory || !matchesQuery) continue;
            final int index = i;
            shown++;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(3), dp(13), dp(3), dp(13));
            list.addView(row, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            row.addView(content, new LinearLayout.LayoutParams(0, -2, 1));

            TextView name = new TextView(this);
            name.setText(s.title);
            name.setTextColor(textColor);
            name.setTextSize(16);
            name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            content.addView(name);

            String previewText = resolveDates(s.body).replace('\n', ' ').trim();
            TextView preview = new TextView(this);
            preview.setText(previewText);
            preview.setTextColor(textColor);
            preview.setTextSize(14);
            preview.setMaxLines(2);
            preview.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, -2);
            previewLp.topMargin = dp(5);
            content.addView(preview, previewLp);

            TextView meta = new TextView(this);
            meta.setText((s.category.isEmpty() ? "Bez kategorii" : s.category) + "  ·  Dotknij kopiuj, aby skopiować cały tekst");
            meta.setTextColor(muted);
            meta.setTextSize(11);
            LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(-1, -2);
            metaLp.topMargin = dp(5);
            content.addView(meta, metaLp);

            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.CENTER);
            row.addView(actions, new LinearLayout.LayoutParams(dp(88), -1));

            TextView copy = new TextView(this);
            copy.setText("▢");
            copy.setTextSize(28);
            copy.setTextColor(accent);
            copy.setGravity(Gravity.CENTER);
            actions.addView(copy, new LinearLayout.LayoutParams(dp(42), dp(48)));
            copy.setOnClickListener(v -> copySnippet(index));

            TextView more = new TextView(this);
            more.setText("⋮");
            more.setTextSize(25);
            more.setTextColor(muted);
            more.setGravity(Gravity.CENTER);
            actions.addView(more, new LinearLayout.LayoutParams(dp(34), dp(48)));
            more.setOnClickListener(v -> showActions(index));
            content.setOnClickListener(v -> showEditor(index));

            View divider = new View(this);
            divider.setBackgroundColor(stroke);
            LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(-1, dp(1));
            list.addView(divider, divLp);
        }
        count.setText(shown + (shown == 1 ? " tekst" : " tekstów"));
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText(snippets.isEmpty() ? "Nie masz jeszcze zapisanych tekstów.\nDodaj pierwszy szablon przyciskiem poniżej." : "Nie znaleziono tekstów.");
            empty.setTextColor(muted);
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(40), dp(18), dp(40));
            list.addView(empty);
        }
    }

    private void showActions(int index) {
        String[] actions = {"Edytuj", "Przenieś do kategorii", "Usuń"};
        new AlertDialog.Builder(this).setItems(actions, (d, which) -> {
            if (which == 0) showEditor(index);
            else if (which == 1) showMoveDialog(index);
            else new AlertDialog.Builder(this).setTitle("Usunąć tekst?").setMessage(snippets.get(index).title)
                    .setNegativeButton("Anuluj", null).setPositiveButton("Usuń", (x, w) -> {
                        snippets.remove(index); saveItems(); renderCategories(); renderList();
                    }).show();
        }).show();
    }

    private void showEditor(int index) {
        boolean editing = index >= 0;
        Snippet old = editing ? snippets.get(index) : new Snippet("", "", "");
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(8), dp(4), 0);
        EditText title = new EditText(this);
        title.setSingleLine(true); title.setHint("Nazwa tekstu"); title.setText(old.title); box.addView(title);
        EditText category = new EditText(this);
        category.setSingleLine(true); category.setHint("Kategoria, np. Biżuteria"); category.setText(old.category); box.addView(category);
        EditText body = new EditText(this);
        body.setHint("Wklej lub wpisz cały tekst…\n\n{{DATA_20}} – dzisiaj, 20:00\n{{DATA_09}} – jutro, 09:00");
        body.setGravity(Gravity.TOP | Gravity.START); body.setMinLines(7); body.setText(old.body); body.setTextSize(14);
        box.addView(body, new LinearLayout.LayoutParams(-1, dp(210)));
        TextView help = new TextView(this);
        help.setText("Daty są automatycznie uzupełniane w chwili kopiowania."); help.setTextColor(muted); help.setTextSize(12); box.addView(help);
        ScrollView wrap = new ScrollView(this); wrap.addView(box);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(editing ? "Edytuj tekst" : "Dodaj tekst")
                .setView(wrap).setNegativeButton("Anuluj", null).setPositiveButton("Zapisz", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn -> {
            String t = title.getText().toString().trim(), c = category.getText().toString().trim(), b = body.getText().toString();
            if (t.isEmpty() || b.trim().isEmpty()) { Toast.makeText(this, "Podaj nazwę i treść tekstu.", Toast.LENGTH_SHORT).show(); return; }
            Snippet s = new Snippet(t, c, b);
            if (editing) snippets.set(index, s); else snippets.add(0, s);
            if (!c.isEmpty()) categoryNames.add(c);
            selectedCategory = "Wszystkie"; saveCategories(); saveItems(); renderCategories(); renderList(); dialog.dismiss();
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(body.getWindowToken(), 0);
        }));
        dialog.show();
    }

    private void copySnippet(int index) {
        String finalText = resolveDates(snippets.get(index).body);
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(snippets.get(index).title, finalText));
        Toast.makeText(this, "Skopiowano: " + snippets.get(index).title, Toast.LENGTH_SHORT).show();
    }

    private String resolveDates(String input) {
        SimpleDateFormat fmt = new SimpleDateFormat("dd.MM.yyyy", new Locale("pl", "PL"));
        Calendar today = Calendar.getInstance();
        String todayAt20 = fmt.format(today.getTime()) + " 20:00";
        today.add(Calendar.DAY_OF_YEAR, 1);
        String tomorrowAt09 = fmt.format(today.getTime()) + " 09:00";
        return input.replace("{{DATA_20}}", todayAt20).replace("{{DATA_09}}", tomorrowAt09);
    }

    private void loadItems() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String rawCats = p.getString(KEY_CATEGORIES, null);
        if (rawCats != null) try {
            JSONArray ca = new JSONArray(rawCats);
            for (int i = 0; i < ca.length(); i++) categoryNames.add(ca.optString(i));
        } catch (Exception ignored) {}
        String raw = p.getString(KEY_ITEMS, null);
        if (raw != null) try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); snippets.add(new Snippet(o.optString("title"), o.optString("category"), o.optString("body"))); }
        } catch (Exception ignored) {}
        for (Snippet item : snippets) if (item.category != null && !item.category.trim().isEmpty()) categoryNames.add(item.category.trim());
        if (snippets.isEmpty() && !p.getBoolean("initialized", false)) {
            snippets.add(new Snippet("🔥 LICYTACJA – BIŻUTERIA 📿", "Biżuteria", "🔥 LICYTACJA – BIŻUTERIA📿\nLicytacja❗️\nStart-40 zł\nPrzebicie: min 5zł\nKoniec licytacji- {{DATA_20}}\nNa sprzedaż nowa biżuteria z próbą 925\n.\nW komplecie łańcuszek 40 cm x 2mm\n.\nWysyłka InPost"));
            saveItems(); p.edit().putBoolean("initialized", true).apply();
        }
    }

    private void saveCategories() {
        JSONArray a = new JSONArray();
        for (String category : categoryNames) a.put(category);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_CATEGORIES, a.toString()).apply();
    }

    private void saveItems() {
        JSONArray a = new JSONArray();
        try { for (Snippet s : snippets) { JSONObject o = new JSONObject(); o.put("title", s.title); o.put("category", s.category); o.put("body", s.body); a.put(o); } }
        catch (Exception ignored) {}
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ITEMS, a.toString()).apply();
    }

    private GradientDrawable roundRect(int color, int border, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), border); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
