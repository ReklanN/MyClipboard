package pl.myclipboard.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "my_clipboard_store";
    private static final String KEY_ITEMS = "items";
    private static final String KEY_CATEGORIES = "categories";
    private final LinkedHashSet<String> categoryNames = new LinkedHashSet<>();
    private final ArrayList<Snippet> snippets = new ArrayList<>();
    private LinearLayout list, categoryStrip;
    private EditText search;
    private TextView count;
    private String selectedCategory = "Wszystkie";
    private int bg, surface, textColor, muted, stroke, accent, chipSelected, chipText;

    static class Snippet {
        String title, category, body;
        Snippet(String t, String c, String b) { title=t; category=c; body=b; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bg = Color.parseColor(night ? "#101014" : "#F6F5F8");
        surface = Color.parseColor(night ? "#1D1C22" : "#FFFFFF");
        textColor = Color.parseColor(night ? "#F4F0F8" : "#201F25");
        muted = Color.parseColor(night ? "#AAA6B2" : "#706D78");
        stroke = Color.parseColor(night ? "#34323B" : "#E6E2EA");
        accent = Color.parseColor(night ? "#D0BCFF" : "#6750A4");
        chipSelected = Color.parseColor(night ? "#51436D" : "#E9DFF8");
        chipText = Color.parseColor(night ? "#FFFFFF" : "#3D2B5D");
        loadItems();
        buildScreen();
        renderCategories();
        renderList();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(12), dp(18), dp(10));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Clipboard");
        title.setTextColor(textColor);
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        count = new TextView(this);
        count.setTextColor(muted);
        count.setTextSize(13);
        header.addView(count);
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("Twoje zapisane teksty");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(2);
        subLp.bottomMargin = dp(14);
        root.addView(subtitle, subLp);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(textColor);
        search.setHintTextColor(muted);
        search.setHint("⌕  Szukaj tekstu...");
        search.setPadding(dp(15), 0, dp(15), 0);
        search.setBackground(roundRect(surface, stroke, 14));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { renderList(); }
            public void afterTextChanged(Editable e) {}
        });

        HorizontalScrollView categoryScroll = new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryStrip = new LinearLayout(this);
        categoryStrip.setOrientation(LinearLayout.HORIZONTAL);
        categoryStrip.setGravity(Gravity.CENTER_VERTICAL);
        categoryScroll.addView(categoryStrip);
        LinearLayout.LayoutParams catLp = new LinearLayout.LayoutParams(-1, dp(48));
        catLp.topMargin = dp(8);
        catLp.bottomMargin = dp(4);
        root.addView(categoryScroll, catLp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(5), 0, dp(12));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView add = new TextView(this);
        add.setText("＋   Dodaj nowy tekst");
        add.setTextColor(Color.WHITE);
        add.setTextSize(16);
        add.setGravity(Gravity.CENTER);
        add.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        add.setBackground(roundRect(accent, accent, 14));
        add.setOnClickListener(v -> showEditor(-1));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(-1, dp(54));
        addLp.topMargin = dp(8);
        root.addView(add, addLp);
        setContentView(root);
    }

    private void renderCategories() {
        if (categoryStrip == null) return;
        categoryStrip.removeAllViews();
        LinkedHashSet<String> cats = new LinkedHashSet<>();
        cats.add("Wszystkie");
        cats.addAll(categoryNames);
        for (Snippet s : snippets) if (s.category != null && !s.category.trim().isEmpty()) cats.add(s.category.trim());
        if (!cats.contains(selectedCategory)) selectedCategory = "Wszystkie";
        for (String cat : cats) {
            TextView chip = new TextView(this);
            chip.setText(cat);
            chip.setTextSize(13);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(15), 0, dp(15), 0);
            boolean selected = cat.equals(selectedCategory);
            chip.setTextColor(selected ? chipText : muted);
            chip.setTypeface(null, selected ? Typeface.BOLD : Typeface.NORMAL);
            chip.setBackground(roundRect(selected ? chipSelected : surface, selected ? chipSelected : stroke, 30));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.rightMargin = dp(8);
            categoryStrip.addView(chip, lp);
            chip.setOnClickListener(v -> { selectedCategory = cat; renderCategories(); renderList(); });
        }
        TextView addCat = new TextView(this);
        addCat.setText("＋ Kategoria");
        addCat.setTextSize(13);
        addCat.setTextColor(accent);
        addCat.setGravity(Gravity.CENTER);
        addCat.setPadding(dp(14), 0, dp(14), 0);
        addCat.setBackground(roundRect(surface, accent, 28));
        categoryStrip.addView(addCat, new LinearLayout.LayoutParams(-2, dp(34)));
        addCat.setOnClickListener(v -> {
            EditText field = new EditText(this);
            field.setSingleLine(true);
            field.setHint("Nazwa kategorii");
            new AlertDialog.Builder(this).setTitle("Nowa kategoria").setView(field)
                .setNegativeButton("Anuluj", null)
                .setPositiveButton("Dodaj", (d, w) -> {
                    String c = field.getText().toString().trim();
                    if (!c.isEmpty() && !c.equals("Wszystkie")) {
                        categoryNames.add(c); saveCategories(); selectedCategory=c;
                        renderCategories(); renderList();
                    }
                }).show();
        });
    }

    private void renderList() {
        if (list == null) return;
        list.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        for (int i = 0; i < snippets.size(); i++) {
            Snippet s = snippets.get(i);
            boolean matchesCategory = selectedCategory.equals("Wszystkie") || selectedCategory.equals(s.category);
            boolean matchesQuery = q.isEmpty() || s.title.toLowerCase(Locale.ROOT).contains(q)
                    || s.category.toLowerCase(Locale.ROOT).contains(q) || s.body.toLowerCase(Locale.ROOT).contains(q);
            if (!matchesCategory || !matchesQuery) continue;
            final int index = i;
            shown++;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(3), dp(13), dp(3), dp(13));
            list.addView(row, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            row.addView(content, new LinearLayout.LayoutParams(0, -2, 1));

            TextView name = new TextView(this);
            name.setText(s.title);
            name.setTextColor(textColor);
            name.setTextSize(16);
            name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            content.addView(name);

            String previewText = resolveDates(s.body).replace('\n', ' ').trim();
            TextView preview = new TextView(this);
            preview.setText(previewText);
            preview.setTextColor(textColor);
            preview.setTextSize(14);
            preview.setMaxLines(2);
            preview.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, -2);
            previewLp.topMargin = dp(5);
            content.addView(preview, previewLp);

            TextView meta = new TextView(this);
            meta.setText((s.category.isEmpty() ? "Bez kategorii" : s.category) + "  ·  Dotknij kopiuj, aby skopiować cały tekst");
            meta.setTextColor(muted);
            meta.setTextSize(11);
            LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(-1, -2);
            metaLp.topMargin = dp(5);
            content.addView(meta, metaLp);

            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.CENTER);
            row.addView(actions, new LinearLayout.LayoutParams(dp(88), -1));

            TextView copy = new TextView(this);
            copy.setText("▢");
            copy.setTextSize(28);
            copy.setTextColor(accent);
            copy.setGravity(Gravity.CENTER);
            actions.addView(copy, new LinearLayout.LayoutParams(dp(42), dp(48)));
            copy.setOnClickListener(v -> copySnippet(index));

            TextView more = new TextView(this);
            more.setText("⋮");
            more.setTextSize(25);
            more.setTextColor(muted);
            more.setGravity(Gravity.CENTER);
            actions.addView(more, new LinearLayout.LayoutParams(dp(34), dp(48)));
            more.setOnClickListener(v -> showActions(index));
            content.setOnClickListener(v -> showEditor(index));

            View divider = new View(this);
            divider.setBackgroundColor(stroke);
            LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(-1, dp(1));
            list.addView(divider, divLp);
        }
        count.setText(shown + (shown == 1 ? " tekst" : " tekstów"));
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText(snippets.isEmpty() ? "Nie masz jeszcze zapisanych tekstów.\nDodaj pierwszy szablon przyciskiem poniżej." : "Nie znaleziono tekstów.");
            empty.setTextColor(muted);
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(40), dp(18), dp(40));
            list.addView(empty);
        }
    }

    private void showActions(int index) {
        String[] actions = {"Edytuj", "Przenieś do kategorii", "Usuń"};
        new AlertDialog.Builder(this).setItems(actions, (d, which) -> {
            if (which == 0) showEditor(index);
            else if (which == 1) {
                ArrayList<String> choices = new ArrayList<>();
                choices.add("Bez kategorii");
                choices.addAll(categoryNames);
                for (Snippet item : snippets) if (!item.category.isEmpty() && !choices.contains(item.category)) choices.add(item.category);
                new AlertDialog.Builder(this).setTitle("Przenieś do kategorii")
                    .setItems(choices.toArray(new String[0]), (dialog, position) -> {
                        snippets.get(index).category = position == 0 ? "" : choices.get(position);
                        saveItems(); selectedCategory="Wszystkie"; renderCategories(); renderList();
                    }).show();
            }
            else new AlertDialog.Builder(this).setTitle("Usunąć tekst?").setMessage(snippets.get(index).title)
                    .setNegativeButton("Anuluj", null).setPositiveButton("Usuń", (x, w) -> {
                        snippets.remove(index); saveItems(); renderCategories(); renderList();
                    }).show();
        }).show();
    }

    private void showEditor(int index) {
        boolean editing = index >= 0;
        Snippet old = editing ? snippets.get(index) : new Snippet("", "", "");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(12), dp(18), dp(10));

        TextView close = new TextView(this);
        close.setText("⊗");
        close.setTextColor(muted);
        close.setTextSize(29);
        close.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(close, new LinearLayout.LayoutParams(-1, dp(60)));
        close.setOnClickListener(v -> restoreMain());

        EditText title = new EditText(this);
        title.setSingleLine(true);
        title.setText(old.title);
        title.setTextColor(textColor);
        title.setHintTextColor(muted);
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setHint("Tytuł (opcjonalnie)");
        title.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, dp(65));
        titleLp.topMargin = dp(14);
        root.addView(title, titleLp);

        View divider = new View(this);
        divider.setBackgroundColor(stroke);
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        EditText body = new EditText(this);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setTextColor(textColor);
        body.setHintTextColor(muted);
        body.setTextSize(17);
        body.setBackgroundColor(Color.TRANSPARENT);
        body.setHint("Treść tekstu...");
        body.setText(old.body);
        body.setPadding(0, dp(22), 0, dp(8));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView chosen = new TextView(this);
        final String[] currentCategory = {old.category};
        chosen.setText("Kategoria: " + (currentCategory[0].isEmpty() ? "Bez kategorii" : currentCategory[0]) + "  ▾");
        chosen.setTextColor(accent);
        chosen.setTextSize(14);
        chosen.setPadding(0, dp(10), 0, dp(10));
        root.addView(chosen);
        chosen.setOnClickListener(v -> {
            ArrayList<String> cats = new ArrayList<>();
            cats.add("Bez kategorii");
            cats.addAll(categoryNames);
            for (Snippet sn : snippets) if (!sn.category.isEmpty() && !cats.contains(sn.category)) cats.add(sn.category);
            cats.add("＋ Nowa kategoria");
            new AlertDialog.Builder(this).setTitle("Wybierz kategorię")
                .setItems(cats.toArray(new String[0]), (dialog, which) -> {
                    if (which == cats.size()-1) {
                        EditText field = new EditText(this);
                        field.setHint("Nazwa kategorii");
                        new AlertDialog.Builder(this).setTitle("Nowa kategoria").setView(field)
                            .setNegativeButton("Anuluj", null)
                            .setPositiveButton("Dodaj", (d, w) -> {
                                String c = field.getText().toString().trim();
                                if (!c.isEmpty()) {
                                    categoryNames.add(c); saveCategories();
                                    currentCategory[0]=c; chosen.setText("Kategoria: "+c+"  ▾");
                                }
                            }).show();
                    } else {
                        currentCategory[0] = which == 0 ? "" : cats.get(which);
                        chosen.setText("Kategoria: " + (currentCategory[0].isEmpty() ? "Bez kategorii" : currentCategory[0]) + "  ▾");
                    }
                }).show();
        });

        TextView hint = new TextView(this);
        hint.setText("Zmienne daty: {{DATA_20}}  ·  {{DATA_09}}");
        hint.setTextColor(muted);
        hint.setTextSize(12);
        root.addView(hint);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams bottomLp = new LinearLayout.LayoutParams(-1, dp(70));
        bottomLp.topMargin = dp(12);
        root.addView(bottom, bottomLp);

        TextView insertToday = editorAction("✦  20:00", muted);
        bottom.addView(insertToday, new LinearLayout.LayoutParams(0, dp(52), 1));
        insertToday.setOnClickListener(v -> body.getText().insert(Math.max(0, body.getSelectionStart()), "{{DATA_20}}"));

        TextView insertTomorrow = editorAction("☷  09:00", muted);
        bottom.addView(insertTomorrow, new LinearLayout.LayoutParams(0, dp(52), 1));
        insertTomorrow.setOnClickListener(v -> body.getText().insert(Math.max(0, body.getSelectionStart()), "{{DATA_09}}"));

        TextView save = editorAction("Zapisz", accent);
        save.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bottom.addView(save, new LinearLayout.LayoutParams(0, dp(52), 1));
        save.setOnClickListener(v -> {
            String b = body.getText().toString();
            String t = title.getText().toString().trim();
            if (b.trim().isEmpty()) {
                Toast.makeText(this, "Wpisz treść tekstu.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (t.isEmpty()) t = b.trim().split("\\n", 2)[0];
            if (t.length() > 55) t = t.substring(0, 55);
            Snippet item = new Snippet(t, currentCategory[0], b);
            if (editing) snippets.set(index, item); else snippets.add(0, item);
            if (!currentCategory[0].isEmpty()) categoryNames.add(currentCategory[0]);
            saveCategories(); saveItems(); selectedCategory="Wszystkie";
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(body.getWindowToken(), 0);
            restoreMain();
        });
        setContentView(root);
    }

    private TextView editorAction(String label, int color) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextSize(15);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private void restoreMain() {
        buildScreen();
        renderCategories();
        renderList();
    }

    private void copySnippet(int index) {
        String finalText = resolveDates(snippets.get(index).body);
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(snippets.get(index).title, finalText));
        Toast.makeText(this, "Skopiowano: " + snippets.get(index).title, Toast.LENGTH_SHORT).show();
    }

    private String resolveDates(String input) {
        SimpleDateFormat fmt = new SimpleDateFormat("dd.MM.yyyy", new Locale("pl", "PL"));
        Calendar today = Calendar.getInstance();
        String todayAt20 = fmt.format(today.getTime()) + " 20:00";
        today.add(Calendar.DAY_OF_YEAR, 1);
        String tomorrowAt09 = fmt.format(today.getTime()) + " 09:00";
        return input.replace("{{DATA_20}}", todayAt20).replace("{{DATA_09}}", tomorrowAt09);
    }

    private void loadItems() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String storedCategories = p.getString(KEY_CATEGORIES, "[]");
        try {
            JSONArray ca = new JSONArray(storedCategories);
            for (int i=0; i<ca.length(); i++) categoryNames.add(ca.optString(i));
        } catch (Exception ignored) {}
        String raw = p.getString(KEY_ITEMS, null);
        if (raw != null) try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); snippets.add(new Snippet(o.optString("title"), o.optString("category"), o.optString("body"))); }
        } catch (Exception ignored) {}
        for (Snippet item : snippets) if (!item.category.isEmpty()) categoryNames.add(item.category);
        if (snippets.isEmpty() && !p.getBoolean("initialized", false)) {
            snippets.add(new Snippet("🔥 LICYTACJA – BIŻUTERIA 📿", "Biżuteria", "🔥 LICYTACJA – BIŻUTERIA📿\nLicytacja❗️\nStart-40 zł\nPrzebicie: min 5zł\nKoniec licytacji- {{DATA_20}}\nNa sprzedaż nowa biżuteria z próbą 925\n.\nW komplecie łańcuszek 40 cm x 2mm\n.\nWysyłka InPost"));
            saveItems(); p.edit().putBoolean("initialized", true).apply();
        }
    }

    private void saveCategories() {
        JSONArray a = new JSONArray();
        for (String c : categoryNames) a.put(c);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_CATEGORIES, a.toString()).apply();
    }

    private void saveItems() {
        JSONArray a = new JSONArray();
        try { for (Snippet s : snippets) { JSONObject o = new JSONObject(); o.put("title", s.title); o.put("category", s.category); o.put("body", s.body); a.put(o); } }
        catch (Exception ignored) {}
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ITEMS, a.toString()).apply();
    }

    private GradientDrawable roundRect(int color, int border, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), border); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
