package pl.myclipboard.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "my_clipboard_store";
    private static final String KEY_ITEMS = "items";
    private final ArrayList<Snippet> snippets = new ArrayList<>();
    private LinearLayout list;
    private EditText search;
    private TextView count;
    private int bg, surface, textColor, muted, stroke;

    static class Snippet {
        String title, category, body;
        Snippet(String t, String c, String b) { title=t; category=c; body=b; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        bg = Color.parseColor(night ? "#121212" : "#F7F6FA");
        surface = Color.parseColor(night ? "#242329" : "#FFFFFF");
        textColor = Color.parseColor(night ? "#F3EFF7" : "#1C1B1F");
        muted = Color.parseColor(night ? "#BDB8C7" : "#68656F");
        stroke = Color.parseColor(night ? "#45414D" : "#E5E1EA");
        loadItems();
        buildScreen();
        renderList();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(18), dp(18), dp(12));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        TextView title = new TextView(this); title.setText("My Clipboard"); title.setTextColor(textColor); title.setTextSize(26); title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        count = new TextView(this); count.setTextColor(muted); count.setTextSize(13); header.addView(count);
        root.addView(header);
        TextView subtitle = new TextView(this); subtitle.setText("Twoje teksty zawsze pod ręką"); subtitle.setTextColor(muted); subtitle.setTextSize(14);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2); subLp.topMargin=dp(4); subLp.bottomMargin=dp(16); root.addView(subtitle, subLp);
        search = new EditText(this); search.setSingleLine(true); search.setTextSize(15); search.setHint("Szukaj tekstu lub kategorii…"); search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(roundRect(surface, stroke, 14));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderList();} public void afterTextChanged(Editable e){}
        });
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0, dp(14), 0, dp(14)); scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Button add = new Button(this); add.setText("＋  Dodaj nowy tekst"); add.setAllCaps(false); add.setTextSize(15);
        add.setOnClickListener(v -> showEditor(-1));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(-1, dp(52)); addLp.topMargin=dp(8); root.addView(add, addLp);
        setContentView(root);
    }

    private void renderList() {
        if (list == null) return;
        list.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int shown=0;
        for (int i=0;i<snippets.size();i++) {
            Snippet s=snippets.get(i);
            if (!q.isEmpty() && !(s.title.toLowerCase(Locale.ROOT).contains(q) || s.category.toLowerCase(Locale.ROOT).contains(q) || s.body.toLowerCase(Locale.ROOT).contains(q))) continue;
            final int index=i; shown++;
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(15),dp(13),dp(15),dp(13)); card.setBackground(roundRect(surface,stroke,16));
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1,-2); cardLp.bottomMargin=dp(10); list.addView(card,cardLp);
            LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = new TextView(this); name.setText(s.title); name.setTextColor(textColor); name.setTextSize(16); name.setTypeface(null,Typeface.BOLD);
            top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            TextView edit = new TextView(this); edit.setText("✎"); edit.setTextSize(20); edit.setTextColor(muted); edit.setPadding(dp(10),dp(2),dp(4),dp(2)); edit.setOnClickListener(v->showEditor(index)); top.addView(edit);
            TextView del = new TextView(this); del.setText("⋮"); del.setTextSize(22); del.setTextColor(muted); del.setPadding(dp(10),0,0,0); del.setOnClickListener(v->showActions(index)); top.addView(del);
            card.addView(top);
            if (!s.category.trim().isEmpty()) { TextView cat=new TextView(this); cat.setText(s.category); cat.setTextColor(muted); cat.setTextSize(12); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(3); card.addView(cat,cp); }
            TextView preview=new TextView(this); preview.setText(resolveDates(s.body)); preview.setTextColor(muted); preview.setTextSize(13); preview.setMaxLines(3); preview.setPadding(0,dp(9),0,dp(10)); card.addView(preview);
            Button copy=new Button(this); copy.setText("Kopiuj tekst"); copy.setAllCaps(false); copy.setTextSize(14); copy.setOnClickListener(v->copySnippet(index)); card.addView(copy,new LinearLayout.LayoutParams(-1,dp(44)));
        }
        count.setText(snippets.size()+" tekstów");
        if (shown==0) { TextView empty=new TextView(this); empty.setText(snippets.isEmpty()?"Nie masz jeszcze tekstów. Dodaj pierwszy szablon.":"Nie znaleziono pasujących tekstów."); empty.setTextColor(muted); empty.setTextSize(14); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(12),dp(36),dp(12),dp(36)); list.addView(empty); }
    }

    private void showActions(int index) {
        String[] actions={"Edytuj", "Usuń"};
        new AlertDialog.Builder(this).setItems(actions,(d,which)->{ if(which==0) showEditor(index); else new AlertDialog.Builder(this).setTitle("Usunąć tekst?").setMessage(snippets.get(index).title).setNegativeButton("Anuluj",null).setPositiveButton("Usuń",(x,w)->{snippets.remove(index);saveItems();renderList();}).show(); }).show();
    }

    private void showEditor(int index) {
        boolean editing=index>=0; Snippet old=editing?snippets.get(index):new Snippet("","","");
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(4),dp(8),dp(4),0);
        EditText title=new EditText(this); title.setSingleLine(true); title.setHint("Nazwa, np. Licytacja – biżuteria"); title.setText(old.title); box.addView(title);
        EditText category=new EditText(this); category.setSingleLine(true); category.setHint("Kategoria (opcjonalnie), np. Biżuteria"); category.setText(old.category); box.addView(category);
        EditText body=new EditText(this); body.setHint("Wklej lub wpisz cały tekst…\n\nZmienne daty:\n{{DATA_20}} – dzisiaj, 20:00\n{{DATA_09}} – jutro, 09:00"); body.setGravity(Gravity.TOP|Gravity.START); body.setMinLines(7); body.setText(old.body); body.setTextSize(14); box.addView(body,new LinearLayout.LayoutParams(-1,dp(210)));
        TextView help=new TextView(this); help.setText("Zmienne są podmieniane w chwili kopiowania."); help.setTextColor(muted); help.setTextSize(12); box.addView(help);
        ScrollView wrap=new ScrollView(this); wrap.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(editing?"Edytuj tekst":"Nowy tekst").setView(wrap).setNegativeButton("Anuluj",null).setPositiveButton("Zapisz",null).create();
        dialog.setOnShowListener(v->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn->{String t=title.getText().toString().trim(), c=category.getText().toString().trim(), b=body.getText().toString(); if(t.isEmpty()||b.trim().isEmpty()){Toast.makeText(this,"Podaj nazwę i treść tekstu.",Toast.LENGTH_SHORT).show();return;} Snippet s=new Snippet(t,c,b); if(editing)snippets.set(index,s);else snippets.add(0,s); saveItems(); renderList(); dialog.dismiss(); ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(body.getWindowToken(),0);});});
        dialog.show();
    }

    private void copySnippet(int index) {
        String finalText=resolveDates(snippets.get(index).body);
        ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(snippets.get(index).title,finalText));
        Toast.makeText(this,"Skopiowano: "+snippets.get(index).title,Toast.LENGTH_SHORT).show();
    }

    private String resolveDates(String input) {
        SimpleDateFormat fmt = new SimpleDateFormat("dd.MM.yyyy", new Locale("pl", "PL"));
        Calendar today = Calendar.getInstance();
        String todayAt20 = fmt.format(today.getTime()) + " 20:00";
        today.add(Calendar.DAY_OF_YEAR, 1);
        String tomorrowAt09 = fmt.format(today.getTime()) + " 09:00";
        return input.replace("{{DATA_20}}", todayAt20).replace("{{DATA_09}}", tomorrowAt09);
    }

    private void loadItems() {
        SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE); String raw=p.getString(KEY_ITEMS,null);
        if(raw!=null) try { JSONArray a=new JSONArray(raw); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);snippets.add(new Snippet(o.optString("title"),o.optString("category"),o.optString("body")));} } catch(Exception ignored) {}
        if(snippets.isEmpty() && !getSharedPreferences(PREFS,MODE_PRIVATE).getBoolean("initialized",false)) {
            snippets.add(new Snippet("🔥 LICYTACJA – BIŻUTERIA 📿","Biżuteria","🔥 LICYTACJA – BIŻUTERIA📿\nLicytacja❗️\nStart-40 zł\nPrzebicie: min 5zł\nKoniec licytacji- {{DATA_20}}\nNa sprzedaż nowa biżuteria z próbą 925\n.\nW komplecie łańcuszek 40 cm x 2mm\n.\nWysyłka InPost"));
            saveItems(); getSharedPreferences(PREFS,MODE_PRIVATE).edit().putBoolean("initialized",true).apply();
        }
    }
    private void saveItems() {
        JSONArray a=new JSONArray(); try { for(Snippet s:snippets){JSONObject o=new JSONObject();o.put("title",s.title);o.put("category",s.category);o.put("body",s.body);a.put(o);} } catch(Exception ignored) {}
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_ITEMS,a.toString()).apply();
    }
    private GradientDrawable roundRect(int color,int border,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),border);return d;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
