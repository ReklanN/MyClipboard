# My Clipboard (Android)

Natywna aplikacja Android w Javie, bez zewnętrznych bibliotek. Teksty są zapisywane lokalnie w `SharedPreferences`; aplikacja działa offline.

## Funkcje
- Dodawanie, edycja i usuwanie pojedynczych szablonów.
- Osobny przycisk kopiowania dla każdego szablonu.
- Wyszukiwanie po nazwie, kategorii i treści.
- Kategorie tekstów.
- Zmienne podstawiane w chwili kopiowania:
  - `{{DATA_20}}` → bieżąca data w formacie `dd.MM.yyyy` oraz `20:00`.
  - `{{DATA_09}}` → następny dzień w formacie `dd.MM.yyyy` oraz `09:00`.
- Motyw systemowy: osobne zasoby `values` i `values-night`.
- Pierwsze uruchomienie zawiera przykładowy szablon licytacji biżuterii; można go edytować lub usunąć.

## Budowanie APK bez Android Studio

Projekt zawiera GitHub Actions workflow w `.github/workflows/build-apk.yml`. GitHub zbuduje APK w chmurze.

1. Zaloguj się lub załóż bezpłatne konto na https://github.com.
2. Utwórz nowe repozytorium (np. `my-clipboard`).
3. Wgraj zawartość folderu `MyClipboard` do repozytorium (możesz użyć opcji **Add file → Upload files** w przeglądarce).
4. Otwórz zakładkę **Actions** i wybierz workflow **Build My Clipboard APK**.
5. Kliknij **Run workflow** (jeśli workflow nie uruchomił się automatycznie po wgraniu plików).
6. Po zakończeniu wybierz uruchomienie workflow, a w sekcji **Artifacts** pobierz `My-Clipboard-APK`.
7. Rozpakuj pobrane archiwum ZIP na telefonie i otwórz `app-debug.apk`, aby zainstalować aplikację.

Przy pierwszej instalacji Android może poprosić o zezwolenie na instalowanie aplikacji z używanej przeglądarki lub menedżera plików.

## Budowanie lokalne
Wymagane: JDK 17, Gradle 8.9 oraz Android SDK Platform 35. Polecenie: `gradle assembleDebug`.
