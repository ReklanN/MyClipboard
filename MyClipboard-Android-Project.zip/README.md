# My Clipboard v3

Pełnoekranowy edytor tekstów, inspirowany przesłanym widokiem:
- Zamknij w lewym górnym rogu
- Tytuł (opcjonalnie)
- Duże pole treści
- Pasek na dole: wstaw datę dzisiejszą 20:00, jutrzejszą 09:00, Zapisz
- Kategorie można tworzyć i wybierać podczas edycji
- Menu ⋮ przy tekście umożliwia przenoszenie do kategorii
- Zapis lokalny, bez internetu

Zmienne: {{DATA_20}} oraz {{DATA_09}}.

Repozytorium GitHub: prześlij archiwum jako `MyClipboard-Android-Project.zip` i użyj workflow `.github/workflows/build-apk.yml` z repozytorium.
